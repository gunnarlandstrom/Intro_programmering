#include <iostream>
#include <string>

int main()
{
  int value{0},sum{0};
  std::cout << "Type in 10 integer values:"<<std::endl;
  std::cin >> value;
  sum +=value;
  std::cin >> value;
   sum +=value;
  std::cin >> value;
   sum +=value;
  std::cin >> value;
   sum +=value;
 std::cout <<"The sum is: " <<sum << std::endl;
  

return 0;
}
 
