#include<iostream>

using namespace std;


int main()
{

  for(int i=0; i<5;i++)
  {
    cout << "hej"<<endl;
    cout << i <<endl;
  }

  
int i=0;
 while( i<5)
 {
     cout << "hej"<<endl;
     i++;
 }

    return 0;
} //end-main