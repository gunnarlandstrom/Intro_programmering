#include <iostream>

int main()
{
    int b=0;
    std::cout <<"Adding 3 numbers and diving by zero!!" <<std::endl;
    std::cout << (1 + 2 + 3) / b <<std::endl;
    return 0;
}
