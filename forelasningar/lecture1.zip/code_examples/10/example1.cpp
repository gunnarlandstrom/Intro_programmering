/**
 * comments
*/
#include <iostream>

int main()
{
  // This is a one line comment
  std::cout << "Welcome to C++!" <<std::endl;
  return 0;
}
