#include <iostream>
using namespace std;
int main()
{
  cout <<"Adding 3 numbers" <<endl;
  cout << (1 + 2 - 3) / 3 << endl;
  return 0;
}
