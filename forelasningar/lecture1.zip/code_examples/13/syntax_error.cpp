#include <iostream>

int main()
{
  std::cout << (1 + 2 + 3) / 3 << std::endl;
  return 0
}
