
#include <iostream>

using namespace std;

 int main() 
 {

    cout << "Välkommen till C++" ;

    return 0;
 } //blocket för main slutar är


