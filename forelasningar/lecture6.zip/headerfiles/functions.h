//Guard preprocessors
#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_

#include <iostream>

using namespace std;

//Functions prototypes
int max(int num1, int num2);
double max(double num1, double num2);
double max(double num1, double num2, double num3);
//End of Guard preprocessor

#endif