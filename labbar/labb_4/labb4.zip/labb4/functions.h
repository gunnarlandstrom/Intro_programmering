#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <fstream>

std::string removeSpecialCharacter(std::string cleanWord);

#endif