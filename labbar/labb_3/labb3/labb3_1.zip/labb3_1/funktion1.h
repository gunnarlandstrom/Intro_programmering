#ifndef FUNKTION1_H
#define FUNKTION1_H
#include <fstream>

bool isFileSorted(std::string fileName);

#endif