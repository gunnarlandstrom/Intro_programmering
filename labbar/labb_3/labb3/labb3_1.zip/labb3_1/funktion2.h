#ifndef FUNKTION2_H
#define FUNKTION2_H

#include <fstream>

void sortFiles(std::string fileNameOne, std::string fileNameTwo, std::string outputFileName);

#endif